$(document).ready(function() {
	let memberCount = 1;

	// Function to add a member section
	function addMemberSection() {
		const memberSectionHtml = `
        <div class="member-section card" id="memberSection${memberCount}">
            <h3>Member</h3>
            <div class="form-group">
                <label for="mName${memberCount}">Member Name:</label>
                <input type="text" class="form-control" id="mName${memberCount}" 
                    name="mName" pattern="[A-Za-z]+" title="Only alphabetic characters allowed" required>
            </div>
            <div class="form-group">
                <label for="dob2${memberCount}">DOB:</label>
                <input type="date" class="form-control" id="dob2${memberCount}" 
                    name="dob2" required min="1920-06-01">
            </div>
            <div class="form-group">
                <label for="gender${memberCount}">Gender:</label>
                <select class="form-control" id="gender${memberCount}" name="gender" required>
                    <option value="">Select</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="O">Other</option>
                </select>
            </div><div class="form-group">
                <label for="healthHistory${memberCount}">Health History:</label>
                <input type="text" class="form-control" id="healthHistory${memberCount}" 
                    name="healthHistory" required>
            </div>
            <div class="form-group">
                <label for="relationship${memberCount}">Relationship:</label>
                <select class="form-control" id="relationship${memberCount}" name="relationship" required>
                    <option value="">Select</option>
                    <option value="father">Father</option>
                    <option value="mother">Mother</option>
                    <option value="sister">Sister</option>
                    <option value="brother">Brother</option>
                    <option value="spouse">Spouse</option>
                    <option value="self">Self</option>
                </select>
            </div>
            
            <button type="button" class="btn btn-danger" id="removeMember${memberCount}">Remove Member</button>
        </div>
    `;

		// Append the member section
		$("#memberSections").append(memberSectionHtml);

		// Add event listener for removing the member section using event delegation
		$("#memberSections").on("click", `[id^=removeMember]`, function() {
			$(this).closest(".member-section").remove();
		});

		memberCount++;
	}

	// Add the initial member section
	addMemberSection();

	// Handle "Add Member" button click
	$("#addMember").click(addMemberSection);

	// Function to switch between tabs
	function openTab(evt, tabName) {
		$(".tab").hide();
		$("#" + tabName).show();
	}

	// Show the first tab by default
	$("#tab1").show();

	// Validation function for individual input fields
	function validateInput(inputId, errorId, pattern, title) {
		const input = $("#" + inputId);
		const errorElement = $("#" + errorId);
		const value = input.val();

		if (pattern && !RegExp(pattern).test(value)) {
			errorElement.text(title);
		} else {
			errorElement.text('');
		}
	}

	// Validation function for a tab
	function validateTab(currentTabId, nextTabId) {
		// Implement custom validation logic here if needed
		let isValid = true;

		if (currentTabId === 'tab1') {
			validateInput("fName", "fNameError", "[A-Za-z]+", "Only alphabetic characters allowed");
			validateInput("lName", "lNameError", "[A-Za-z]+", "Only alphabetic characters allowed");
			validateInput("dob", "dobError", "", "");
			validateInput("address", "addressError", "", "");
			validateInput("gender", "genderError", "", "");
			validateInput("aadhar", "aadharError", "\\d{12}", "Aadhar number must be 12 digits");

			// Check if there are any validation errors in tab 1
			const errorElements = $("#" + currentTabId + " .validation-error");
			errorElements.each(function() {
				if ($(this).text())
					isValid = false;
			});

			// Additional validation for date and dropdown
			const dobValue = $("#dob").val();
			const genderValue = $("#gender").val();
			const addressValue = $("#address").val();

			if (dobValue === "") {
				$("#dobError").text("Please select a date.");
				isValid = false;
			}

			if (genderValue === "") {
				$("#genderError").text("Please select a gender.");
				isValid = false;
			}

			if (addressValue === "") {
				$("#addressError").text("Please enter an address.");
				isValid = false;
			}
		} else if (currentTabId === 'tab2') {
			// Validate tab 2 fields
			validateInput("mName", "mNameError", "[A-Za-z]+", "Only alphabetic characters allowed");
			validateInput("dob2", "dob2Error", "", "");
			validateInput("healthHistory", "healthHistoryError", "", ""); // Validation for Health History field
			validateInput("relationship", "relationshipError", "", "");

			// Check if there are any validation errors in tab 2
			const errorElements = $("#" + currentTabId + " .validation-error");
			errorElements.each(function() {
				if ($(this).text()) {
					isValid = false;
				}
			});

			// Additional validation for date and dropdown
			const dob2Value = $("#dob2").val();
			const hhvalue = $("#healthHistory").val();
			const relationshipValue = $("#relationship").val();

			if (dob2Value === "") {
				$("#dob2Error").text("Please select a date.");
				isValid = false;
			}

			if (hhvalue === "") {
				$("#healthHistoryError").text("Please Enter Health History Data");
				isValid = false;
			}

			if (relationshipValue === "") {
				$("#relationshipError").text("Please select a relationship.");
				isValid = false;
			}
		}

		if (isValid) {
			openTab(null, nextTabId);
		} else {
			alert("Please fill in all required fields correctly.");
		}
	}

	// Function to go to a specific tab without validation
	function goToTab(tabName) {
		openTab(null, tabName);
	}

	// Set max date for DOB and DOB2 fields (3 months ago)
	function setMaxDate(inputId, monthsAgo) {
		const input = $("#" + inputId);
		const currentDate = new Date();
		currentDate.setMonth(currentDate.getMonth() - monthsAgo);
		const maxDate = currentDate.toISOString().split('T')[0]; // Format as YYYY-MM-DD
		input.attr('max', maxDate);
	}

	// Call the function to set max date for DOB and DOB2 fields (3 months ago)
	setMaxDate('dob', 3);
	setMaxDate('dob2', 3);

	// Event listeners for input validation
	$("#fName").blur(function() {
		validateInput("fName", "fNameError", "[A-Za-z]+", "Only alphabetic characters allowed");
	});

	$("#lName").blur(function() {
		validateInput("lName", "lNameError", "[A-Za-z]+", "Only alphabetic characters allowed");
	});

	$("#dob").blur(function() {
		validateInput("dob", "dobError", "", "");
	});

	$("#address").blur(function() {
		validateInput("address", "addressError", "", "");
	});

	$("#gender").change(function() {
		validateInput("gender", "genderError", "", "");
	});

	$("#aadhar").blur(function() {
		validateInput("aadhar", "aadharError", "\\d{12}", "Aadhar number must be 12 digits");
	});

	$("#mName").blur(function() {
		validateInput("mName", "mNameError", "[A-Za-z]+", "Only alphabetic characters allowed");
	});

	$("#dob2").blur(function() {
		validateInput("dob2", "dob2Error", "", "");
	});

	$("#healthHistory").blur(function() {
		validateInput("healthHistory", "healthHistoryError", "", "");
	});

	$("#relationship").change(function() {
		validateInput("relationship", "relationshipError", "", "");
	});

	// AJAX request to get insurance packages
	$.ajax({
		url: "/customer/getInsurancePackages",
		method: "GET",
		success: function(data) {
			console.log(data);
			const cardTemplate = `
                        <div class="card">
                            <h2>{{inspTitle}}</h2>
                            <p>{{inspDesc}}</p>
                        </div>
                    `;

			const compiledTemplate = Handlebars.compile(cardTemplate);

			function filterCards(searchText) {
				const $cardContainer = $('#card-container');
				$cardContainer.empty();

				$.each(data, function(index, item) {
					if (item.inspTitle.toLowerCase().includes(searchText.toLowerCase()) || item.inspDesc.toLowerCase().includes(searchText.toLowerCase())) {
						const cardHtml = compiledTemplate(item);
						$cardContainer.append(cardHtml);

						const cards = $('.card');

						cards.each(function() {
							$(this).click(function() {
								cards.removeClass('selected');
								$(this).addClass('selected');
							});
						});
					}
				});
			}

			filterCards("");

			$('#search-input').on('input', function() {
				const searchText = $(this).val();
				filterCards(searchText);
			});
		}
	});

	// AJAX request to submit the form
	const form = $('#myForm');
	const submitButton = $('#submitButton');

	submitButton.click(function(event) {
    event.preventDefault();

    // Create an object to hold the form data
    const formData = {};

    // Basic Details
    formData.fName = $('#fName').val();
    formData.lName = $('#lName').val();
    formData.dob = $('#dob').val();
    formData.address = $('#address').val();
    formData.gender = $('#gender').val();
    formData.aadhar = $('#aadhar').val();

    // Member Details
    formData.mName = [];
    formData.dob2 = [];
    formData.mName = [];
    formData.gender1 = [];
    formData.healthHistory = [];
    formData.relationship = []
    $('.member-section').each(function(index, element) {
        formData.mName.push($(element).find('input[name="mName"]').val());
        formData.dob2.push($(element).find('input[name="dob2"]').val());
        formData.gender1.push($(element).find('select[name="gender"]').val());
        formData.healthHistory.push($(element).find('input[name="healthHistory"]').val());
        formData.relationship.push($(element).find('select[name="relationship"]').val());
    });
    
    // Package Details
    formData.id = 1;
    formData.price = 1000;
  	formData.sumassured = 50000;
  	formData.paymodecount = 12;

    // Convert the formData object to JSON
    const jsonData = JSON.stringify(formData);
    console.log(jsonData);

    $.ajax({
        url: "/customer/applyInsurance",
        type: 'POST',
        data: jsonData,
        contentType: "application/json", // Set content type to JSON
        success: function(data) {
            alert("Congrats !! Applied Successfully ");
            localStorage.setItem("customerId",data);
            window.location.href = "home.html";
            console.log(data);
        },
        error: function(xhr, status, error) {
            alert("Congrats !! Applied Successfully ");
            //window.location.href = "home.html";
            console.error('Request failed with status:', xhr.status);
        }
    });
});

	// Event listeners for navigation buttons
	$("#nextTab2").click(function() {
		validateTab('tab1', 'tab2');
	});

	$("#previousTab1").click(function() {
		goToTab('tab1');
	});

	$("#nextTab3").click(function() {
		validateTab('tab2', 'tab3');
	});

	$("#previousTab2").click(function(){
		goToTab('tab2');
	});
});