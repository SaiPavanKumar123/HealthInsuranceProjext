var claimId;
$.ajax({
	url: '/customer/getAllClaimsById',
	method: 'GET',
	data: { 'customerId': localStorage.getItem('customerId') },
	success: function(data) {
		claimId = data[0];
		console.log(data);
		var dropdown = $('#claimDropdown');
		dropdown.empty();
		$.each(data, function(index, option) {
			dropdown.append('<option value="' + option + '">' + option + '</option>');
		});

		dropdown.change(function() {
			claimId = $('#claimDropdown').val();
			$.ajax({
				url: "/customer/getAllDataByClaimId",
				data: {
					"claimId": claimId
				},
				success: function(jsonData) {
					console.log(jsonData);

					// for step 1
					$("#step1-body").empty();
					$("#step1-body").append($("<div>").html(`Applied For: ${jsonData.patientNames[0]}`));
					$("#step1-body").append($("<div>").html(`Amount Requested: ${jsonData.claim.clamAmountRequested}`));
					$("#step1-body").append($("<div>").html(`Applied On: ${jsonData.claim.clamDate}`));


					// for step 2
					$("#step2-body").empty();
					if (jsonData.claimBill.length == 0) $("#step2-body").html("<b>No Documents Uploaded</b>")

					jsonData.claimBill.forEach((item) => {
						console.log(item.clbl_document_title);
						$("#step2-body").html($("#step2-body").html() + `Doc: ${item.clbl_document_title}<br>`);
					});

					// for step 3
					$("#step2-card").nextUntil('.vertical-line-green').remove();
					generateCard('Additional Documents ⏳', jsonData);

				},
				error: function(error) {
					console.log(error);
				}
			});

			function generateCard(heading, jsonData) {
				// Create the vertical blue line
				var verticalLine = $('<div>', {
					class: 'vertical-line-blue m-1'
				});

				// Create the card element
				var card = $('<div>', {
					class: 'card claim-flow-step'
				});

				// Create the card header
				var cardHeader = $('<div>', {
					class: 'card-header inprogress',
					role: 'button',
					'data-toggle': 'collapse',
					'data-target': '#step3',
					text: heading
				});

				// Create the collapse section
				var collapseSection = $('<div>', {
					class: 'collapse',
					id: 'step3'
				});

				// Create the card body
				var cardBody = $('<div>', {
					class: 'card-body',
					id: 'step3-body'
				});

				// Create the form
				var reuploadsForm = $('<form>', {
					id: 'reuploads-form',
					action: `/customer/adduploadsFile?claimId=${claimId}`,
					enctype: 'multipart/form-data',
					method: 'post'
				});

				$.each(jsonData.reuploads, function(index, element) {
					// Create a div based on the status
					var elementDiv;
					if (element.status === null) {
						// If status is null, create a div with an input field
						elementDiv = $('<div>').append(
							$('<h6>', { text: element.name }),
							$('<input>', { type: element.type, name: element.name }),
							$('<br>'),
							$('<span>', { text: element.description })
						);
						var submitButton = $('<button>', {
							type: 'submit',
							id: 'submitButton',
							class: 'btn btn-success m-2',
							text: 'Submit'
						});
						reuploadsForm.append(
							$('<hr>'),
							submitButton
						);


					} else if (element.status === "uploaded") {
						// If status is "uploaded", create a div with a label and a download button
						var fileName = jsonData.uploads.filter(upload => upload.reUploadId === element.uploadId)[0].data;
						console.log(fileName);
						elementDiv = $('<div>').append(
							$('<label>', { text: fileName }),
							$('<br>'),
							$('<button>', {
								type: 'button',
								text: 'Download File',
								click: function() {
									console.log(fileName);
									window.location.href = `/file/${fileName}`;
								}
							}).addClass('download-btn'));
					}

					// Append the created div to the form
					reuploadsForm.append(elementDiv);
				});


				// Append the form to the card body
				cardBody.append(reuploadsForm);

				// Create the card footer
				var cardFooter = $('<div>', {
					class: 'card-footer',
					role: 'button',
					'data-toggle': 'collapse',
					'data-target': '#step3',
					text: 'View Details'
				});

				// Append elements to the card and collapse section
				card.append(cardHeader);
				collapseSection.append(cardBody);
				card.append(collapseSection);
				card.append(cardFooter);

				// Append the vertical line and card to the body
				$('.main').append(verticalLine);
				$('.main').append(card);
			}

		});

	}
});

