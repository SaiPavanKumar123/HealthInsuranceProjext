$(document).ready(function() {
  // Handle form submission
  $("#check-price-form").submit(function(event) {
    event.preventDefault();
    
    localStorage.setItem("userEmail",$("#email").val());

    // Perform an AJAX POST request to your server for authentication
    $.ajax({
      type: "POST",
      url: "/customer/login", // Replace with your server endpoint
      success: function(response) {
        // Assuming the server returns a success status, you can redirect to home.html
        if (1) {
          window.location.href = "otp.html";
        } else {
          // Handle authentication failure (e.g., display an error message)
          alert("Authentication failed. Please check your credentials.");
        }
      },
      error: function(error) {
        // Handle AJAX request error
        console.error("AJAX Error: " + JSON.stringify(error));
        window.location.href = "otp.html";
      }
    });
  });
});