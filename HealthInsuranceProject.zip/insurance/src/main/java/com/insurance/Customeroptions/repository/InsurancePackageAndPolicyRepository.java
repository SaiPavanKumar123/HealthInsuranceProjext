package com.insurance.Customeroptions.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.Customeroptions.contracts.InterfaceInsurancePolicyandPackageDAO;
import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;
import com.insurance.Customeroptions.contracts.*;

@Repository
public class InsurancePackageAndPolicyRepository implements InterfaceInsurancePackageAndPolicyRepository {
    @Autowired
    InterfaceInsurancePolicyandPackageDAO idao;

    // Method to get all insurance policies
    public List<InsurancePolicy> getAllInsurancePolicies() {
        return idao.getAllInsurancePolicies();
    }

    // Method to get all FAQs
    public List<Faq> getAllFAQS() {
        return idao.getAllFAQS();
    }

    // Method to get insurance policies for a specific customer
    public List<InsurancePolicy> getCustomerInsurancePolicy(int cust) {
        return idao.getCustomerInsurancePolicy(cust);
    }

    // Method to get all insurance packages
    public List<InsurancePackages> getInsurancePackages() {
        return idao.getInsurancePackages();
    }

    // Method to add a customer
    public Long addCustomer(FormData loan) {
        
		return idao.addCustomer(loan) ;
    }

    // Method to get general FAQs
    public List<Faq> getGeneralFAQS() {
        return idao.getGeneralFAQS();
    }

    // Method to get coverage and benefits FAQs
    public List<Faq> getCoverageandBenefitsFAQS() {
        return idao.getCoverageandBenefitsFAQS();
    }
}
