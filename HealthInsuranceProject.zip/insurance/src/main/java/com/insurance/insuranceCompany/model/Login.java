package com.insurance.insuranceCompany.model;

public class Login {
	int userId;
	String username;
	String password;
	int roleid;

	public Login() {

	}

	public Login(int userId, String username, String password, int roleid) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.roleid = roleid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public int getRoleid() {
		return roleid;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}

	@Override
	public String toString() {
		return "LoginClass [userId=" + userId + ", username=" + username + ", password=" + password + ", roleid="
				+ roleid + "]";
	}

}
