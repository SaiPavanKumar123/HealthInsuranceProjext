package com.insurance.insuranceCompany.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.insuranceCompany.contract.LoginContract;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.rowMapper.LoginClassMapper;

@Component
public class LoginDaoLayer implements LoginContract {
	@Autowired
	JdbcTemplate jdbc;

	@Override
	public Login checkCredentials(Login lc) {
		String sql = "SELECT COUNT(*) FROM logintable WHERE username = '" + lc.getUsername() + "' and password='"
				+ lc.getPassword() + "'";
		int count = jdbc.queryForObject(sql, Integer.class);
		if (count == 0)
			return null;
		String sql1 = "SELECT * FROM logintable WHERE username = '" + lc.getUsername() + "' and password='"
				+ lc.getPassword() + "'";
		Login log = jdbc.queryForObject(sql1, new LoginClassMapper());
		return log;
	}

	@Override
	public int resetpwd(String email, String pwd) {
		return jdbc.update("update logintable set password='" + pwd + "' where username='" + email + "'");
	}

	@Override
	public int checkMail(String email) {
		String sql = "SELECT COUNT(*) FROM logintable WHERE username = ?";
		return jdbc.queryForObject(sql, Integer.class, email);
	}

	@Override
	public int checkAccess(int lc, String string) {
		String sql = "SELECT COUNT(*) FROM roleprivelegetable AS rp INNER JOIN privelegestable AS p ON rp.priv_id = p.priv_id WHERE rp.role_id ="
				+ lc + "AND p.priv_pattern = '" + string + "'";
		return jdbc.queryForObject(sql, Integer.class);
	}
}
