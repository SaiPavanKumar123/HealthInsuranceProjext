package com.insurance.insuranceCompany.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.contract.InsurancePackageServiceContract;
import com.insurance.insuranceCompany.model.Categories;
import com.insurance.insuranceCompany.model.DiseaseDetails;
import com.insurance.insuranceCompany.model.InsurancePackage;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.repository.InsurancePackageRepository;

@Controller
@RequestMapping("/insurance")
public class InsurancePackageController {

    @Autowired
    InsurancePackageRepository ipr;
    private InsurancePackageServiceContract insurancePackageServiceContract;
    HttpSession session;
    private static final Logger logger = LoggerFactory.getLogger(InsurancePackageController.class);

    @Autowired
    public InsurancePackageController(InsurancePackageServiceContract insurancePackageServiceContract,
            HttpSession session) {
        this.insurancePackageServiceContract = insurancePackageServiceContract;
        this.session = session;
    }

    // Handle GET request to retrieve a list of all insurance packages
    @GetMapping("/list")
    public String getAllInsurancePackages(Model model, HttpSession session) {
        try {
            logger.trace("Entering getAllInsurancePackages method");

            // Check if the user is logged in
            Object lc = session.getAttribute("login");
            if (lc == null || (int) lc == 0) {
                logger.warn("User attempted to access 'list' without logging in.");
                model.addAttribute("noaccess", "You need to login first");
                model.addAttribute("login", new Login());
                return "loginPage";
            }

            // Retrieve data from the service
            List<InsurancePackage> insurancePackages = insurancePackageServiceContract.getAllInsurancePackages();
            model.addAttribute("insurancePackages", insurancePackages);

            logger.info("Retrieved {} insurance packages successfully", insurancePackages.size());

            return "package"; // You can return the name of the Thymeleaf template as needed
        } catch (Exception e) {
            logger.error("An error occurred while fetching insurance packages", e);
            // You can handle the error here, e.g., by returning an error view
            return "error"; // Return an error view in case of an error
        } finally {
            logger.trace("Exiting getAllInsurancePackages method");
        }
    }

    // Handle GET request to view disease details for a specific ID
    @GetMapping("/diseasedetails/{discId}")
    public String viewDiseseDetails(@PathVariable int discId, Model model) {
        try {
            logger.trace("Entering viewDiseseDetails method");
            logger.info("Fetching disease details for ID: {}", discId);

            DiseaseDetails dd = insurancePackageServiceContract.getDiseaseDetailsById(discId);
            model.addAttribute("diseasedetails", dd);

            logger.info("Fetched disease details for ID: {} successfully", discId);

            return "diseasedetail"; // You can return the name of the Thymeleaf template as needed
        } catch (Exception e) {
            logger.error("An error occurred while fetching disease details for ID: {}", discId, e);
            // You can handle the error here, e.g., by returning an error view
            return "error"; // Return an error view in case of an error
        } finally {
            logger.trace("Exiting viewDiseseDetails method");
        }
    }

    // Handle GET request to start the packages page
    @RequestMapping(value = "/start")
    public String packages() {
        return "redirect:/list";
    }

    // Handle GET request to filter insurance packages based on status and age
    @GetMapping("/filteredpackages")
    public String getFilteredPackages(@RequestParam("status") String status, @RequestParam("age") String age,
            Model model) {
        try {
            logger.trace("Entering getFilteredPackages method");
            logger.info("Filtering insurance packages by status: {} and age: {}", status, age);

            List<InsurancePackage> insurancePackages;

            if ("ALL".equals(status) && age.equals("")) {
                insurancePackages = insurancePackageServiceContract.getAllInsurancePackages();
            } else if ("ALL".equals(status) && !age.equals("")) {
                insurancePackages = insurancePackageServiceContract.getAllInsurancePackagesByAge(Integer.parseInt(age));
            } else {
                if (age.equals("")) {
                    insurancePackages = insurancePackageServiceContract.getPackagesByStatus(status);
                } else {
                    insurancePackages = insurancePackageServiceContract.getFilteredPackages(status,
                            Integer.parseInt(age));
                }
            }

            model.addAttribute("insurancePackages", insurancePackages);

            logger.info("Filtered insurance packages count: {}", insurancePackages.size());

            return "package";
        } catch (Exception e) {
            logger.error("An error occurred while filtering insurance packages by status: {} and age: {}", status, age,
                    e);

            return "package";
        } finally {
            logger.trace("Exiting getFilteredPackages method");
        }
    }

    // Handle GET request to download insurance package data as an Excel file
    @RequestMapping(value = "/excel")
    public void downloadExcel(@RequestParam("status") String status, @RequestParam("age") String age,
            HttpServletResponse response) throws IOException {
        try {
            logger.trace("Entering downloadExcel method");

            List<InsurancePackage> insurancePackages = new ArrayList<>();

            if ("ALL".equals(status) && age.equals("")) {
                insurancePackages = insurancePackageServiceContract.getAllInsurancePackages();
            } else if ("ALL".equals(status) && !age.equals("")) {
                insurancePackages = insurancePackageServiceContract.getAllInsurancePackagesByAge(Integer.parseInt(age));
            } else {
                if (age.equals("")) {
                    insurancePackages = insurancePackageServiceContract.getPackagesByStatus(status);
                } else {
                    insurancePackages = insurancePackageServiceContract.getFilteredPackages(status, Integer.parseInt(age));
                }
            }

            Workbook workbook = new XSSFWorkbook();
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Packages List");
            Row headerRow = sheet.createRow(0);

            // Define column headings
            headerRow.createCell(0).setCellValue("PackageId");
            headerRow.createCell(1).setCellValue("PackageTitle");
            headerRow.createCell(2).setCellValue("Description");
            headerRow.createCell(3).setCellValue("Status");
            headerRow.createCell(4).setCellValue("Amount Start Range");
            headerRow.createCell(5).setCellValue("Amount End Range");
            headerRow.createCell(6).setCellValue("Age Limit Start");
            headerRow.createCell(7).setCellValue("Age Limit End");

            int rowIdx = 1;
            for (InsurancePackage insurance : insurancePackages) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(insurance.getInspId());
                row.createCell(1).setCellValue(insurance.getInspTitle());
                row.createCell(2).setCellValue(insurance.getInspDescription());
                row.createCell(3).setCellValue(insurance.getInspStatus());
                row.createCell(4).setCellValue(insurance.getInspRangeStart());
                row.createCell(5).setCellValue(insurance.getInspRangeEnd());
                row.createCell(6).setCellValue(insurance.getInspAgeLimitStart());
                row.createCell(7).setCellValue(insurance.getInspAgeLimitEnd());
            }

            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=packages.xlsx");
            OutputStream outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.close();
            workbook.close();

            logger.info("Excel downloaded successfully");

        } catch (Exception e) {
            logger.error("An error occurred while downloading Excel", e);
        } finally {
            logger.trace("Exiting downloadExcel method");
        }
    }

    // Handle GET request to fetch diseases for a specific insurance package
    @GetMapping(value = "/diseases/{inspId}/{inspTitle}")
    public String getDiseases(@PathVariable int inspId, @PathVariable String inspTitle, Model model) {
        try {
            logger.trace("Entering getDiseases method");
            logger.info("Fetching diseases for insurance package ID: {}", inspId);

            List<DiseaseDetails> diseases = insurancePackageServiceContract.getDiseasesByPackageId(inspId);
            model.addAttribute("inspId", inspId);
            model.addAttribute("inspTitle", inspTitle);
            model.addAttribute("diseases", diseases);

            logger.info("Retrieved {} diseases for insurance package ID: {}", diseases.size(), inspId);

            return "diseasedetail"; // You can return the name of the Thymeleaf template as needed

        } catch (Exception e) {
            logger.error("An error occurred while fetching diseases", e);
            // You can handle the error here, e.g., by returning an error view
            // or redirecting to an error page
            return "diseasedetails"; // Return an error view in case of an error
        } finally {
            logger.trace("Exiting getDiseases method");
        }
    }

    // Handle POST request to add a new disease to an insurance package
    @PostMapping("diseases/{id}/addDiseaseBh")
    @ResponseBody
    public String addDisease(@RequestParam String name, String ICDCode, String Description, String inspId) {
        try {
            logger.trace("Entering addDisease method");
            logger.info("Adding disease with name: {} for insurance package ID: {}", name, inspId);

            System.out.println("Bha ra" + inspId);
            int message = ipr.addDisease(name, ICDCode, Description, "Active", Integer.parseInt(inspId));

            if (message == 1) {
                logger.info("Disease added successfully for insurance package ID: {}", inspId);
                return "record added successfully";
            } else {
                logger.error("Error occurred while adding disease for insurance package ID: {}", inspId);
                return "error occurred while adding record";
            }
        } catch (Exception e) {
            logger.error("An error occurred in addDisease", e);
            return "error occurred while adding record"; // Handle the error and return an appropriate message
        } finally {
            logger.trace("Exiting addDisease method");
        }
    }

    // Handle POST request to delete a disease from an insurance package
    @PostMapping("diseases/{id}/deleteDiseaseBh")
    public String deleteDisease(@RequestParam int did, int inspId) {
        try {
            logger.trace("Entering deleteDisease method");
            logger.info("Deleting disease with ID: {} for insurance package ID: {}", did, inspId);

            System.out.println(did + " " + inspId);
            int message = ipr.deleteDisease(did, inspId);

            if (message == 1) {
                logger.info("Disease deleted successfully for disease ID: {} and insurance package ID: {}", did, inspId);
                return "record deleted successfully";
            } else {
                logger.error("Error occurred while deleting disease for disease ID: {} and insurance package ID: {}", did, inspId);
                return "error occurred while deleting record";
            }
        } catch (Exception e) {
            logger.error("An error occurred in deleteDisease", e);
            return "error occurred while deleting record"; // Handle the error and return an appropriate message
        } finally {
            logger.trace("Exiting deleteDisease method");
        }
    }

    // Handle POST request to edit disease details
    @PostMapping("diseases/{id}/editDiseaseBh")
    @ResponseBody
    public String editDisease(@RequestParam String name, String ICDCode, String Description, String Status, String Id, Model model) {
        String message;
        try {
            logger.trace("Entering editDisease method");
            logger.info("Editing disease with Id: {}", Id);

            message = ipr.editDisease(name, ICDCode, Description, Status, Id);

            logger.info("Disease with Id: {} edited successfully", Id);

        } catch (Exception e) {
            logger.error("An error occurred while editing disease record with Id: {}", Id, e);
            return "error occurred while editing record"; // Handle the error gracefully by returning an error message
        } finally {
            logger.trace("Exiting editDisease method");
        }

        return message;
    }

    // Handle GET request to get categories for an insurance package
    @GetMapping(value = "/categories/{inspId}/{inspTitle}")
    public String getCategories(@PathVariable int inspId, @PathVariable String inspTitle, Model model) {
        try {
            logger.trace("Entering getCategories method");
            logger.info("Getting categories for Insurance Package ID: {}", inspId);

            List<Categories> diseases = insurancePackageServiceContract.getCategoriesByPackageId(inspId);

            int insId = inspId;
            model.addAttribute("inspId", insId);
            model.addAttribute("inspTitle", inspTitle);
            model.addAttribute("categories", diseases);

            logger.info("Retrieved {} categories for Insurance Package ID: {}", diseases.size(), inspId);

            return "Categories";
        } catch (Exception e) {
            logger.error("An error occurred in getCategories", e);

            return "Categories";
        } finally {
            logger.trace("Exiting getCategories method");
        }
    }

    // Handle POST request to delete a category
    @PostMapping("categories/{id}/deleteCategory")
    @ResponseBody
    public String deleteCategory(@RequestParam String cid, String inspId) {
        try {
            logger.trace("Entering deleteCategory method");

            int categoryId = Integer.parseInt(cid);
            int insurancePackageId = Integer.parseInt(inspId);

            logger.info("Deleting category with ID {} for Insurance Package ID: {}", categoryId, insurancePackageId);

            int message = ipr.deleteCategory(categoryId, insurancePackageId);

            if (message == 1) {
                logger.info("Category deleted successfully");
                return "record deleted successfully";
            } else {
                logger.error("Error occurred while deleting category");
                return "error occurred while deleting record";
            }
        } catch (Exception e) {
            logger.error("An error occurred in deleteCategory", e);
            return "An error occurred while deleting record"; // Return a generic error message
        } finally {
            logger.trace("Exiting deleteCategory method");
        }
    }

    // Handle POST request to add a new category
    @PostMapping("categories/{id}/addCategory")
    @ResponseBody
    public String addCategory(@RequestParam String Title, String Description, String inspId) {
        try {
            logger.trace("Entering addCategory method");

            int insurancePackageId = Integer.parseInt(inspId);

            logger.info("Adding a category for Insurance Package ID: {}", insurancePackageId);

            int message = ipr.addCategory("", Title, Description, "Ac", insurancePackageId);

            if (message == 1) {
                logger.info("Category added successfully");
                return "record added successfully";
            } else {
                logger.error("Error occurred while adding category");
                return "error occurred while adding record";
            }
        } catch (Exception e) {
            logger.error("An error occurred in addCategory", e);
            return "An error occurred while adding record"; // Return a generic error message
        } finally {
            logger.trace("Exiting addCategory method");
        }
    }

    // Handle POST request to edit a category
    @PostMapping("categories/{id}/editCategory")
    @ResponseBody
    public String editCategory(@RequestParam String Title, String Description, String Status, String inspId, Model model) {
        try {
            logger.trace("Entering editCategory method");

            int insurancePackageId = Integer.parseInt(inspId);

            logger.info("Editing a category for Insurance Package ID: {}", insurancePackageId);

            String message = ipr.editCategory(Title, Description, Status);

            // Add the updated categories to the model
            model.addAttribute("categories", insurancePackageServiceContract.getCategoriesByPackageId(insurancePackageId));

            return message;
        } catch (Exception e) {
            logger.error("An error occurred in editCategory", e);
            return "An error occurred while editing category"; // Return a generic error message
        } finally {
            logger.trace("Exiting editCategory method");
        }
    }

    // Handle POST request to delete insurance packages
    @PostMapping("/deletePackagesBh")
    @ResponseBody
    public String deletePackages(@ModelAttribute("did") String insp) {
        try {
            logger.trace("Entering deletePackages method");

            int insurancePackageId = Integer.parseInt(insp);

            logger.info("Deleting an Insurance Package with ID: {}", insurancePackageId);

            int message = ipr.deletePackage(insurancePackageId);

            if (message == 1) {
                logger.info("Insurance Package with ID {} deleted successfully", insurancePackageId);
                return "record deleted successfully";
            }
        } catch (Exception e) {
            logger.error("An error occurred in deletePackages", e);
        } finally {
            logger.trace("Exiting deletePackages method");
        }

        logger.error("Failed to delete Insurance Package with ID: {}", insp);
        return "error occurred while deleting record";
    }

    // Handle POST request to edit insurance packages
    @PostMapping("/editPackageBh")
    @ResponseBody
    public String editPackage(@RequestParam String Id, String title, String Description, String status,
            String rangeStart, String rangeEnd, String ageLimitStrt, String ageLimitEnd, Model model) {
        try {
            logger.trace("Entering editPackage method");
            logger.info("Editing package with ID: {}", Id);

            String message = ipr.editPackage(Id, title, Description, status, rangeStart, rangeEnd, ageLimitStrt,
                    ageLimitEnd);

            logger.info("Package edited successfully with message: {}", message);

            return message;
        } catch (Exception e) {
            logger.error("An error occurred while editing the package with ID: {}", Id, e);
            return "An error occurred while editing the package.";
        } finally {
            logger.trace("Exiting editPackage method");
        }
    }

    // Handle POST request to add insurance packages
    @PostMapping("/addPackageBh")
    @ResponseBody
    public String addPackage(@RequestBody InsurancePackage insurancePackage) {
        try {
            logger.trace("Entering addPackage method");

            // Perform the operation to add the InsurancePackage here
            ipr.addPackage(insurancePackage);

            logger.info("New Insurance Package added successfully");

            return "Record added successfully"; // Return a success message
        } catch (Exception e) {
            logger.error("An error occurred in addPackage", e);
            return "An error occurred while adding the record."; // Return an error message
        } finally {
            logger.trace("Exiting addPackage method");
        }
    }
}
