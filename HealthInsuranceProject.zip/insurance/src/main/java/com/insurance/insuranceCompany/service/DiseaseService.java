package com.insurance.insuranceCompany.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.contract.DiseaseDAOInterface;
import com.insurance.insuranceCompany.model.Disease;
@Service
public class DiseaseService {
	@Autowired
	DiseaseDAOInterface ddi;

	public ArrayList<Disease> getAllDisease() {
		return ddi.getAllDisease();
	}
}
