package com.insurance.insuranceCompany.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance.insuranceCompany.model.InsurancePolicy;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.repository.InsuranceRepositorySch;

@Controller
@RequestMapping("/insurance")
public class InsuranceScheduleController {
	@Autowired
	private InsuranceRepositorySch insuRepository;
	private static final Logger logger = LoggerFactory.getLogger(InsuranceScheduleController.class);


	@Autowired
	HttpSession session;

	// to view pages
	@GetMapping("/policyhome")
	public String getAllLinks(Model model) {
	    logger.trace("Entering getAllLinks method");
	    
	    Object lc = session.getAttribute("login");
	    if (lc == null || (int) lc == 0) {
	        logger.warn("User not logged in, redirecting to loginPage");
	        model.addAttribute("noaccess", "You need to login first");
	        model.addAttribute("login", new Login());
	        return "loginPage";
	    }
	    
	    logger.info("User is logged in, displaying Links page");
	    return "Links";
	}


	// To view Policies
	@GetMapping("/getpolicy")
	public String getAllPolicy(Model model) {
	    logger.trace("Entering getAllPolicy method");
	    
	    List<InsurancePolicy> policies = insuRepository.listAllPolicy();
	    model.addAttribute("policies", policies);
	    
	    logger.info("Retrieved policy data");
	    
	    return "ViewPolicy";
	}

	// To view schedule at insurance side
	@GetMapping("/getpolicySchedule")
	public String getAllPolicySchedule(Model model) {
	    try {
	        logger.trace("Entering getAllPolicySchedule method");

	         
	        model.addAttribute("schedules",insuRepository.listAllPolicySchedules());

	        logger.info("Retrieved policy schedules successfully");
	        return "ViewSchedule";
	    } catch (Exception e) {
	        logger.error("An error occurred in getAllPolicySchedule", e);
	        model.addAttribute("errorMessage", "An error occurred while fetching policy schedules.");
	        return "errorPage"; // Customize this according to your error page setup
	    } finally {
	        logger.trace("Exiting getAllPolicySchedule method");
	    }
	}


	// To view Policy for Policy Approval
	@GetMapping("/updatepolicy")
	public String updateFormStatus(Model model) {
	    try {
	        logger.trace("Entering updateFormStatus method");

	        List<InsurancePolicy> p = insuRepository.listAllPolicy();
	        model.addAttribute("policies", p);

	        logger.info("Retrieved insurance policies successfully");
	        return "StatusApproval";
	    } catch (Exception e) {
	        logger.error("An error occurred in updateFormStatus", e);
	        model.addAttribute("errorMessage", "An error occurred while fetching insurance policies.");
	        return "StatusApproval"; // Return the same view with an error message
	    } finally {
	        logger.trace("Exiting updateFormStatus method");
	    }
	}


	// To Update Status of a particular policy
	@GetMapping("/UpdatestatusPolicy")
	public String updatedStatusPolicy(@ModelAttribute("policy") InsurancePolicy policy) {
	    try {
	        logger.trace("Entering updatedStatusPolicy method");

	        // Update the status of the policy using insuRepository
	        insuRepository.updateNewPolicy(policy);

	        logger.info("Updated policy status successfully");
	        return "redirect:/insurance/getpolicy"; // Redirect to the "/getpolicy" endpoint
	    } catch (Exception e) {
	        logger.error("An error occurred in updatedStatusPolicy", e);
	        // Handle the error as needed, maybe return an error page or display a message
	        return "redirect:/insurance/getpolicy"; // Redirect to the "/getpolicy" endpoint in case of an error
	    } finally {
	        logger.trace("Exiting updatedStatusPolicy method");
	    }
	}


	// To get no of months that a particular policy has not been paid
	@GetMapping("/nonPaymentStatus")
	public String getNonPaymentStatus(@RequestParam("iplcId") int id, Model m) {
	    try {
	        logger.trace("Entering getNonPaymentStatus method");
	        int p = insuRepository.listNonStatusPayments(id);
	        m.addAttribute("policies", p);
	        logger.info("Retrieved non-payment status successfully");
	        return "ViewNonPaymentStatus";
	    } catch (Exception e) {
	        logger.error("An error occurred in getNonPaymentStatus", e);
	        return "ViewNonPaymentStatus";
	    } finally {
	        logger.trace("Exiting getNonPaymentStatus method");
	    }
	}


	// To get into distinct policy id page for checking non status payment checking
	@GetMapping("/StatusPaymentById")
	public String getDistinctIplcIds(Model model) {
	    try {
	        logger.trace("Entering getDistinctIplcIds method");
	        List<Integer> distinctIplcIds = insuRepository.findDistinctIds();
	        model.addAttribute("distinctIplcIds", distinctIplcIds);
	        logger.info("Retrieved distinct iplcIds successfully");
	        return "StatusById";
	    } catch (Exception e) {
	        logger.error("An error occurred in getDistinctIplcIds", e);
	        return "StatusById";
	    } finally {
	        logger.trace("Exiting getDistinctIplcIds method");
	    }
	}


	// To get distinct policy id for get particular schedule
	@GetMapping("/ScheduleById")
	public String getScheduleDistinctIplcIds(Model model) {
	    try {
	        logger.trace("Entering getScheduleDistinctIplcIds method");
	        List<Integer> distinctIplcIds = insuRepository.findDistinctIds();
	        model.addAttribute("distinctIplcIds", distinctIplcIds);
	        logger.info("Retrieved distinct iplcIds successfully");
	        return "ViewScheduleById";
	    } catch (Exception e) {
	        logger.error("An error occurred in getScheduleDistinctIplcIds", e);
	        return "ViewScheduleById";
	    } finally {
	        logger.trace("Exiting getScheduleDistinctIplcIds method");
	    }
	}


	// to get particular Schedule of particular policy id
	@GetMapping("/getpolicyScheduleById")
	public String getAllPolicyScheduleById(@RequestParam("iplcId") int id, Model m) {
	    try {
	        logger.trace("Entering getAllPolicyScheduleById method");
	        m.addAttribute("schedules", insuRepository.listAllPolicySchedulesById(id));
	        logger.info("Retrieved policy schedules by id successfully");
	        return "ViewScheduleByIds";
	    } catch (Exception e) {
	        logger.error("An error occurred in getAllPolicyScheduleById", e);
	        return "ViewScheduleByIds";
	    } finally {
	        logger.trace("Exiting getAllPolicyScheduleById method");
	    }
	}

}