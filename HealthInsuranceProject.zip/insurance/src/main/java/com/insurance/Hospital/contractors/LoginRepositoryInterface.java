package com.insurance.Hospital.contractors;

public interface LoginRepositoryInterface {
	
	int sendmail(String to_mail);
}
