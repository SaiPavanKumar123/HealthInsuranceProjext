package com.insurance.Hospital.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.insurance.Hospital.contractors.DashboardServiceInterface;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.Claim;

@Controller
@RequestMapping(value="/hospital")
public class DashboardController {
	
    Logger logger = LoggerFactory.getLogger(DashboardController.class);

    DashboardServiceInterface dashboardServiceInterface;

    @Autowired
    public DashboardController(DashboardServiceInterface dashboardServiceInterface) {
        this.dashboardServiceInterface = dashboardServiceInterface;
    }

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String getDashBoard() {
    	
    	System.out.println("366363");
        try {
            // returns the dashboard page
            return "index";
        } catch (Exception e) {
            logger.error("Error occurred in getDashBoard(): " + e.getMessage());
            throw e;
        }
    }

    @RequestMapping(value = "/applicants", method = RequestMethod.GET)
    public String getAllClaims(Model model) {
        try {
            // this gives the information about the Applicants list
        	logger.info("Generating all the Applicants");
            List<Claim> claims = dashboardServiceInterface.getAllApplicants();
            model.addAttribute("claims", claims);
            logger.trace("Generated list with count "+claims.size());

            // this gives the information about the active applicants in the fin year
            logger.info("Generated all the Applicants List ");

            List<Claim> activeApplicants = dashboardServiceInterface.getActiveApplicants();
            model.addAttribute("activeApplicants", activeApplicants);
            logger.trace("Generated all the Active Applicants List i.e. "+activeApplicants.size());
            //get all the active applicants fromt he hospital side
            return "applicants";
        } catch (Exception e) {
            logger.error("Error occurred in getAllClaims(): " + e.getMessage());
            throw e;
        }
    }

    @RequestMapping(value = "/rejected", method = RequestMethod.GET)
    public String getAllRejectedLoans(Model model) {
        try {
            // this shows all rejected bills.
        	logger.info("Generating of Rejected Bills");
            List<ClaimBills> claimbills = dashboardServiceInterface.getRejectedLoans();
            logger.trace("List of Rejected Bills"+claimbills.size());
            model.addAttribute("rejectedbills", claimbills);
            //list the rejected bills by the hospital..
            return "rejected";
        } catch (Exception e) {
            logger.error("Error occurred in getAllRejectedLoans(): " + e.getMessage());
            throw e;
        }
    }

    @RequestMapping(value = "/claims", method = RequestMethod.GET)
    public String getClaimedValue(Model model) {
        try {
        	logger.info("Total Amount Claimed by the Hospital");
            List<Claim> amtReceived = dashboardServiceInterface.getClaimedAmount();
            // shows the complete claimed amount by the hospital
            logger.trace("List of Total Amount Claimed by the Hospital "+amtReceived);
            model.addAttribute("claims", amtReceived);

            List<Claim> totalAmt = dashboardServiceInterface.getTotalAmount();
            // shows the amount claimed and to be claimed for the financial year (status="paid" or "pending")
            logger.trace("List of Remaining amount to be claimed");
            model.addAttribute("total_amount", totalAmt);

            return "claimvalue";
        } catch (Exception e) {
            logger.error("Error occurred in getClaimedValue(): " + e.getMessage());
            throw e;
        }
    }
}
