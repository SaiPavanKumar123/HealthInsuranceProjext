package com.insurance.Hospital.services;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.Hospital.contractors.ClaimDaoInterface;
import com.insurance.Hospital.contractors.ClaimServiceInterface;

import com.insurance.Hospital.models.Claim;
import com.insurance.Hospital.models.ClaimApplication;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.PolicyMembers;
import com.insurance.Hospital.models.ReUpload;
import com.insurance.Hospital.models.Uploads;

import jakarta.servlet.http.HttpServletResponse;

@Service
public class ClaimService implements ClaimServiceInterface {

	@Autowired
	ClaimDaoInterface claimDaoInterface;

	// LIstClaims
	@Override
	public ArrayList<Claim> getAllClaims() {
		// TODO Auto-generated method stub
		return (ArrayList<Claim>) claimDaoInterface.getAllClaims();
	}

	@Override
	public ArrayList<Claim> getFilteredClaims(String status) {
		// TODO Auto-generated method stub
		return (ArrayList<Claim>) claimDaoInterface.getFilteredClaims(status);
	}

	@Override
	public Claim getClaimById(int clamId) {
		// TODO Auto-generated method stub
		return claimDaoInterface.getClaimById(clamId);
	}

	// New Claim

	@Override
	public void addClaimApplication(ClaimApplication application) {
		claimDaoInterface.addClaimApplication(application);

	}

	@Override
	public void addClaim(int clamIplcId, double requestAmount, String hospname) {
		claimDaoInterface.addClaim(clamIplcId, requestAmount, hospname);

	}

	@Override
	public Claim getClaimByid(int clamIplcId) {
		return claimDaoInterface.getClaimByid(clamIplcId);
	}

	@Override
	public void addClaimBills(ClaimBills bill) {
		claimDaoInterface.addClaimBills(bill);

	}

	@Override
	public List<String> getFamilyByPolicy(int id) {

		List<PolicyMembers> members = claimDaoInterface.getFamilyByPolicy(id);
		List<String> names = new ArrayList<>();

		for (PolicyMembers mem : members) {
			if (mem.getInsurancePolicyId() == id) {
				names.add(mem.getMemberName());
			}
		}
		return names;
	}

	// Upload

	@Override
	public List<ReUpload> getAllReUploads(int id) {
		return claimDaoInterface.getAllReUploads(id);
	}

	@Override
	public List<Uploads> getAllUploads(int claimId) {
		return claimDaoInterface.getAllUploads(claimId);
	}

	@Override
	public void addUploads(Uploads up) {
		claimDaoInterface.addUploads(up);

	}

	@Override
	public void updateReUploads(int reuploadId, int claimId) {
		claimDaoInterface.updateReUploads(reuploadId, claimId);

	}

	@Override
	public boolean checkPolicyIdStatus(int policyId) {

		return claimDaoInterface.checkPolicyIdStatus(policyId);
	}

	@Override
	public void downloadExcel(String status, HttpServletResponse response) {
		// TODO Auto-generated method stub
		System.out.println("madh");
		ArrayList<Claim> Claims = new ArrayList<>();
		if (status.equals("select")) {
			Claims = (ArrayList<Claim>) claimDaoInterface.getAllClaims();
		} else {
			Claims = (ArrayList<Claim>) claimDaoInterface.getFilteredClaims(status);
		}
		System.out.println(status + "Satish");
		System.out.println(Claims.size());

		// Create an Excel workbook using Apache POI
		Workbook workbook = new XSSFWorkbook();
		org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Claims Data");
		Row headerRow = sheet.createRow(0);

		// Define column headings
		headerRow.createCell(0).setCellValue("Claim_Id");
		headerRow.createCell(1).setCellValue("ClamSource");
		headerRow.createCell(2).setCellValue("ClamType");
		headerRow.createCell(3).setCellValue("ClamDate");
		headerRow.createCell(4).setCellValue("ClamAmountRequestedt");
		headerRow.createCell(5).setCellValue("ClamIplcId");
		headerRow.createCell(6).setCellValue("ClamProcessedAmount");
		headerRow.createCell(7).setCellValue("ClamProcessedDate");
		headerRow.createCell(8).setCellValue("ClamProcessedBy");
		headerRow.createCell(9).setCellValue("ClamRemarks");
		headerRow.createCell(10).setCellValue("ClamStatus");

		int rowIdx = 1;
		for (Claim claim : Claims) {
			Row row = sheet.createRow(rowIdx++);
			row.createCell(0).setCellValue(claim.getClamId());
			row.createCell(1).setCellValue(claim.getClamSource());
			row.createCell(2).setCellValue(claim.getClamType());
			row.createCell(3).setCellValue(claim.getClamDate());
			row.createCell(4).setCellValue(claim.getClamAmountRequested());
			row.createCell(5).setCellValue(claim.getClamIplcId());
			row.createCell(6).setCellValue(claim.getClamProcessedAmount());
			row.createCell(7).setCellValue(claim.getClamProcessedDate());
			row.createCell(8).setCellValue(claim.getClamProcessedBy());
			row.createCell(9).setCellValue(claim.getClamRemarks());
			row.createCell(10).setCellValue(claim.getClamStatus());

		}

		// Set the response headers for Excel download
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=claims.xlsx");

		// Write the Excel data to the response output stream
		OutputStream outputStream;
		try {
			outputStream = response.getOutputStream();
			workbook.write(outputStream);
			outputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	@Override
	public boolean checkRequestedAmount(int clamIplcId, double claimAmountRequested) {
		return claimDaoInterface.checkRequestedAmount(clamIplcId,claimAmountRequested);

	}

	


}